package com.mycompany.booksstore.Books;

public interface interNotForSale {
    
}
