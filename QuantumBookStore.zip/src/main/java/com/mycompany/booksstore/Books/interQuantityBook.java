package com.mycompany.booksstore.Books;

public interface interQuantityBook {
    public int getQuantity();
    public void setQuantity(int quantity);
    public void reduceQuantity();
}
