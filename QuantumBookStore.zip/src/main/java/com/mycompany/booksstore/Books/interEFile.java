package com.mycompany.booksstore.Books;

public interface interEFile {
     public String getFileType();
}
